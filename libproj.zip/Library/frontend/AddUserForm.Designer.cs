namespace LibraryFrontend
{
    partial class AddUserForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label labelRole;
        private System.Windows.Forms.ComboBox comboBoxRole;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Button buttonCancel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labelName = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.labelRole = new System.Windows.Forms.Label();
            this.comboBoxRole = new System.Windows.Forms.ComboBox();
            this.buttonOK = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // labelName
            this.labelName.Text = "Name:";
            this.labelName.Location = new System.Drawing.Point(20, 20);
            this.labelName.AutoSize = true;
            // textBoxName
            this.textBoxName.Location = new System.Drawing.Point(100, 17);
            this.textBoxName.Width = 200;
            // labelRole
            this.labelRole.Text = "Role:";
            this.labelRole.Location = new System.Drawing.Point(20, 60);
            this.labelRole.AutoSize = true;
            // comboBoxRole
            this.comboBoxRole.Location = new System.Drawing.Point(100, 57);
            this.comboBoxRole.Width = 200;
            this.comboBoxRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxRole.Items.AddRange(new object[] { "Admin", "Member" });
            // buttonOK
            this.buttonOK.Text = "OK";
            this.buttonOK.Location = new System.Drawing.Point(100, 100);
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // buttonCancel
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.Location = new System.Drawing.Point(200, 100);
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // Add controls
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.labelRole);
            this.Controls.Add(this.comboBoxRole);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.buttonCancel);
            // Form settings
            this.ClientSize = new System.Drawing.Size(340, 150);
            this.Text = "Add User";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
