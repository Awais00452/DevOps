using System;
using System.Linq;
using System.Windows.Forms;
using Backend; // Add this at the top if your backend namespace is 'Backend'

namespace LibraryFrontend
{
    public partial class Form1 : Form
    {
        private Library library;
        private BindingSource booksBindingSource = new BindingSource();
        private BindingSource usersBindingSource = new BindingSource();

        public Form1()
        {
            InitializeComponent();
            library = new Library();
            library.LoadData(); // Loads data from inventory.txt, users.txt
            BindData();
            dataGridViewUsers.SelectionChanged += dataGridViewUsers_SelectionChanged;
        }

        private void BindData()
        {
            booksBindingSource.DataSource = library.Books;
            dataGridViewBooks.DataSource = booksBindingSource;
            usersBindingSource.DataSource = library.Users;
            dataGridViewUsers.DataSource = usersBindingSource;
            dataGridViewTransactions.DataSource = null;
            dataGridViewTransactions.DataSource = library.Transactions;
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            string query = textBoxSearch.Text.Trim().ToLower();
            var filtered = library.Books
                .Where(b => b.Title.ToLower().Contains(query) || b.Author.ToLower().Contains(query) || b.ISBN.ToLower().Contains(query))
                .ToList();
            dataGridViewBooks.DataSource = null;
            dataGridViewBooks.DataSource = filtered;
        }

        private void buttonAddBook_Click(object sender, EventArgs e)
        {
            using (var dlg = new AddBookForm())
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        library.AddBook(dlg.NewBook);
                        BindData();
                        toolStripStatusLabel.Text = $"Book '{dlg.NewBook.Title}' added successfully.";
                    }
                    catch (Exception ex)
                    {
                        toolStripStatusLabel.Text = $"Error adding book: {ex.Message}";
                    }
                }
            }
        }

        private void buttonBorrow_Click(object sender, EventArgs e)
        {
            if (dataGridViewBooks.CurrentRow?.DataBoundItem is Book selectedBook)
            {
                var userSelectionForm = new UserSelectionForm(library.Users.Values.ToList());
                if (userSelectionForm.ShowDialog() == DialogResult.OK)
                {
                    var user = userSelectionForm.SelectedUser;
                    if (user == null)
                    {
                        toolStripStatusLabel.Text = "No user selected.";
                        return;
                    }
                    var result = library.BorrowBook(user.UserId, selectedBook.ISBN);
                    BindData();
                    toolStripStatusLabel.Text = result == null ? $"Book '{selectedBook.Title}' borrowed by {user.Name}." : result;
                }
            }
            else
            {
                toolStripStatusLabel.Text = "Select a book to borrow.";
            }
        }

        private void buttonReturn_Click(object sender, EventArgs e)
        {
            if (dataGridViewBooks.CurrentRow?.DataBoundItem is Book selectedBook)
            {
                var userSelectionForm = new UserSelectionForm(library.Users.Values.ToList());
                if (userSelectionForm.ShowDialog() == DialogResult.OK)
                {
                    var user = userSelectionForm.SelectedUser;
                    if (user == null)
                    {
                        toolStripStatusLabel.Text = "No user selected.";
                        return;
                    }
                    var result = library.ReturnBook(user.UserId, selectedBook.ISBN);
                    BindData();
                    toolStripStatusLabel.Text = result == null ? $"Book '{selectedBook.Title}' returned by {user.Name}." : result;
                }
            }
            else
            {
                toolStripStatusLabel.Text = "Select a book to return.";
            }
        }

        private void dataGridViewUsers_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewUsers.CurrentRow?.DataBoundItem is User selectedUser)
            {
                var borrowedBookIds = library.Transactions
                    .Where(t => t.UserId == selectedUser.Id && t.Action == "Borrow")
                    .Select(t => t.BookId)
                    .ToHashSet();
                var returnedBookIds = library.Transactions
                    .Where(t => t.UserId == selectedUser.Id && t.Action == "Return")
                    .Select(t => t.BookId)
                    .ToHashSet();
                var currentlyBorrowed = borrowedBookIds.Except(returnedBookIds).ToList();
                var borrowedBooks = library.Books
                    .Where(b => currentlyBorrowed.Contains(b.Id))
                    .Select(b => $"{b.Title} ({b.Category})")
                    .ToList();
                listBoxBorrowedBooks.DataSource = borrowedBooks;
            }
            else
            {
                listBoxBorrowedBooks.DataSource = null;
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            buttonSearch.Click += buttonSearch_Click;
            buttonAddBook.Click += buttonAddBook_Click;
            buttonBorrow.Click += buttonBorrow_Click;
            buttonReturn.Click += buttonReturn_Click;
            buttonAddUser.Click += buttonAddUser_Click;
            buttonExportBooks.Click += buttonExportBooks_Click;
        }

        private void buttonExportBooks_Click(object sender, EventArgs e)
        {
            using (var sfd = new SaveFileDialog { Filter = "CSV files (*.csv)|*.csv", FileName = "books.csv" })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        using (var writer = new System.IO.StreamWriter(sfd.FileName))
                        {
                            writer.WriteLine("Id,Title,Author,ISBN,Available,Category");
                            foreach (var book in library.Books)
                            {
                                writer.WriteLine($"{book.Id},\"{book.Title}\",\"{book.Author}\",\"{book.ISBN}\",{book.Available},\"{book.Category}\"");
                            }
                        }
                        toolStripStatusLabel.Text = "Books exported successfully.";
                    }
                    catch (Exception ex)
                    {
                        toolStripStatusLabel.Text = $"Export failed: {ex.Message}";
                    }
                }
            }
        }

        private void buttonAddUser_Click(object sender, EventArgs e)
        {
            using (var dlg = new AddUserForm())
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        library.AddUser(dlg.NewUser);
                        BindData();
                        toolStripStatusLabel.Text = $"User '{dlg.NewUser.Name}' added successfully.";
                    }
                    catch (Exception ex)
                    {
                        toolStripStatusLabel.Text = $"Error adding user: {ex.Message}";
                    }
                }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            library.SaveData(); // Save data to files on close
        }
    }
}
