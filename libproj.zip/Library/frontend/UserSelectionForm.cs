using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Backend;

namespace LibraryFrontend
{
    public partial class UserSelectionForm : Form
    {
        public User SelectedUser { get; private set; }
        private List<User> users;

        public UserSelectionForm(List<User> users)
        {
            InitializeComponent();
            this.users = users;
            listBoxUsers.DataSource = users;
            listBoxUsers.DisplayMember = "Name";
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            SelectedUser = listBoxUsers.SelectedItem as User;
            DialogResult = DialogResult.OK;
            Close();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
