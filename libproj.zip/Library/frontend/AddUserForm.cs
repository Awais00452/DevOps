using System;
using System.Windows.Forms;

namespace LibraryFrontend
{
    public partial class AddUserForm : Form
    {
        public User NewUser { get; private set; }

        public AddUserForm()
        {
            InitializeComponent();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            NewUser = new User
            {
                Name = textBoxName.Text.Trim(),
                Role = comboBoxRole.SelectedItem?.ToString() ?? "Member"
            };
            DialogResult = DialogResult.OK;
            Close();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
