namespace LibraryFrontend
{
    partial class AddBookForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.TextBox textBoxTitle;
        private System.Windows.Forms.Label labelAuthor;
        private System.Windows.Forms.TextBox textBoxAuthor;
        private System.Windows.Forms.Label labelISBN;
        private System.Windows.Forms.TextBox textBoxISBN;
        private System.Windows.Forms.CheckBox checkBoxAvailable;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.ComboBox comboBoxCategory;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labelTitle = new System.Windows.Forms.Label();
            this.textBoxTitle = new System.Windows.Forms.TextBox();
            this.labelAuthor = new System.Windows.Forms.Label();
            this.textBoxAuthor = new System.Windows.Forms.TextBox();
            this.labelISBN = new System.Windows.Forms.Label();
            this.textBoxISBN = new System.Windows.Forms.TextBox();
            this.checkBoxAvailable = new System.Windows.Forms.CheckBox();
            this.buttonOK = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.labelCategory = new System.Windows.Forms.Label();
            this.comboBoxCategory = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // labelTitle
            this.labelTitle.Text = "Title:";
            this.labelTitle.Location = new System.Drawing.Point(20, 20);
            this.labelTitle.AutoSize = true;
            // textBoxTitle
            this.textBoxTitle.Location = new System.Drawing.Point(100, 17);
            this.textBoxTitle.Width = 200;
            // labelAuthor
            this.labelAuthor.Text = "Author:";
            this.labelAuthor.Location = new System.Drawing.Point(20, 60);
            this.labelAuthor.AutoSize = true;
            // textBoxAuthor
            this.textBoxAuthor.Location = new System.Drawing.Point(100, 57);
            this.textBoxAuthor.Width = 200;
            // labelISBN
            this.labelISBN.Text = "ISBN:";
            this.labelISBN.Location = new System.Drawing.Point(20, 100);
            this.labelISBN.AutoSize = true;
            // textBoxISBN
            this.textBoxISBN.Location = new System.Drawing.Point(100, 97);
            this.textBoxISBN.Width = 200;
            // checkBoxAvailable
            this.checkBoxAvailable.Text = "Available";
            this.checkBoxAvailable.Location = new System.Drawing.Point(100, 177);
            // buttonOK
            this.buttonOK.Text = "OK";
            this.buttonOK.Location = new System.Drawing.Point(100, 220);
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // buttonCancel
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.Location = new System.Drawing.Point(200, 220);
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // labelCategory
            this.labelCategory.Text = "Category:";
            this.labelCategory.Location = new System.Drawing.Point(20, 140);
            this.labelCategory.AutoSize = true;
            // comboBoxCategory
            this.comboBoxCategory.Location = new System.Drawing.Point(100, 137);
            this.comboBoxCategory.Width = 200;
            this.comboBoxCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCategory.Items.AddRange(new object[] { "Fiction", "Non-Fiction", "Science", "History", "Biography" });
            // Add controls
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.textBoxTitle);
            this.Controls.Add(this.labelAuthor);
            this.Controls.Add(this.textBoxAuthor);
            this.Controls.Add(this.labelISBN);
            this.Controls.Add(this.textBoxISBN);
            this.Controls.Add(this.checkBoxAvailable);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.labelCategory);
            this.Controls.Add(this.comboBoxCategory);
            // Form settings
            this.ClientSize = new System.Drawing.Size(340, 270);
            this.Text = "Add Book";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
