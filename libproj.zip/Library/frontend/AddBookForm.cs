using System;
using System.Windows.Forms;

namespace LibraryFrontend
{
    public partial class AddBookForm : Form
    {
        public Book NewBook { get; private set; }

        public AddBookForm()
        {
            InitializeComponent();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            NewBook = new Book
            {
                Title = textBoxTitle.Text.Trim(),
                Author = textBoxAuthor.Text.Trim(),
                ISBN = textBoxISBN.Text.Trim(),
                Available = checkBoxAvailable.Checked,
                Category = comboBoxCategory.SelectedItem?.ToString() ?? ""
            };
            DialogResult = DialogResult.OK;
            Close();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
